//
//  FileBrowser.h
//  FileBrowser
//
//  Created by Roy Marmelstein on 07/02/2016.
//  Copyright © 2016 Roy Marmelstein. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FileBrowser.
FOUNDATION_EXPORT double FileBrowserVersionNumber;

//! Project version string for FileBrowser.
FOUNDATION_EXPORT const unsigned char FileBrowserVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FileBrowser/PublicHeader.h>


